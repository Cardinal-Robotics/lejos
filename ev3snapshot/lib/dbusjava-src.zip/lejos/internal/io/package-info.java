/**
 * 
 */
/**
 * @author Lawrie Griiffiths
 *
 */
package lejos.internal.io;