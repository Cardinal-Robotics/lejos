package lejos.hardware;

public interface LED {
	
	public void setPattern(int pattern);

}
