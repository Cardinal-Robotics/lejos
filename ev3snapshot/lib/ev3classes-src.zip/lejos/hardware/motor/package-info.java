/**
 * Access to the motors that the EV3 supports. 
 * 
 * Motors supported by specific controllers are in lejos.hardwae.device.
 */
package lejos.hardware.motor;