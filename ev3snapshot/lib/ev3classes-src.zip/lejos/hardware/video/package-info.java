/**
 * Access to video devices
 */
package lejos.hardware.video;