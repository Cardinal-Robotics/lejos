package lejos.hardware.ev3;

import lejos.hardware.Brick;

public interface EV3 extends Brick
{
}

